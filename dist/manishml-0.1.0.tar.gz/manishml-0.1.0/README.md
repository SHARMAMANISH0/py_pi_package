# Manishml

newdlharsh is a simple Python package that allows users to greet someone with a friendly message.

## Installation

You can install the mlharsh package from PyPI (after it's uploaded) using pip:

```bash
pip install Manishml