def say_hello(name):
    """A simple function to greet someone"""
    return f"hello,{name}! welcome to the package"